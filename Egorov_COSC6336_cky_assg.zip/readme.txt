My user name on CodaLab: Maxikfu

To run program you need to modify following parameters in file cky.py:
 1) Provide grammar file path on line 111
 2) Provide path to test set file  on line 112

Type into terminal:
>> python cky.py

Output will be produced into file submission.txt each parse tree one line.
Program may take many hours to run to produce output for all test set even if grammar was build with sentences 8 or less words.
To decrease time need to decrease number of grammar rules.

To produce grammar from PennTreebank you can run
>>python cnf_grammar.py
all grammar rules will be in the file grammar.txt